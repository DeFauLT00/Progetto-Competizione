/* mi sono sbizzarito con il js dopo che ho considerato terminata la consegna */

/* ---- costanti - inizio ---- */
const allineaTitoloBottone = document.getElementById('allinea-titolo-bottone');
const missionSection       = document.getElementById('mission-section');

const strategy    = document.getElementById('prima-colonna');
const design      = document.getElementById('seconda-colonna');
const development = document.getElementById('terza-colonna');
/* ---- costanti - fine ---- */

missionSection.addEventListener('mouseenter', () => {       // quando il mouse entra nella mission section
    allineaTitoloBottone.style.opacity = '0';
});

missionSection.addEventListener('mouseleave', () => {       // quando il mouse esce dalla mission section
    allineaTitoloBottone.style.opacity = '1';
});

/* con questa funzione ho capito come fai ingrigire le colonne
    strategy, design e development nella strategy section */

strategy.addEventListener('mouseenter', () => {       // quando il mouse entra nella strategy section
    design.style.opacity = '0.5';
    development.style.opacity = '0.5';
});
strategy.addEventListener('mouseleave', () => {       // quando il mouse esce dalla strategy section
    strategy.style.opacity = '1';
    design.style.opacity = '1';
    development.style.opacity = '1';
});

design.addEventListener('mouseenter', () => {       // quando il mouse entra nella strategy section
    strategy.style.opacity = '0.5';
    development.style.opacity = '0.5';
});
design.addEventListener('mouseleave', () => {       // quando il mouse esce dalla strategy section
    strategy.style.opacity = '1';
    design.style.opacity = '1';
    development.style.opacity = '1';
});

development.addEventListener('mouseenter', () => {       // quando il mouse entra nella strategy section
    design.style.opacity = '0.5';
    strategy.style.opacity = '0.5';
});
development.addEventListener('mouseleave', () => {       // quando il mouse esce dalla strategy section
    strategy.style.opacity = '1';
    design.style.opacity = '1';
    development.style.opacity = '1';
});